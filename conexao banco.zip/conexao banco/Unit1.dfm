object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 299
  ClientWidth = 635
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 328
    Top = 192
    Width = 105
    Height = 49
    Caption = 'oracle 19'
  end
  object Edit1: TEdit
    Left = 344
    Top = 40
    Width = 121
    Height = 21
    TabOrder = 0
    Text = 'ADMIN'
  end
  object Edit2: TEdit
    Left = 344
    Top = 67
    Width = 121
    Height = 21
    TabOrder = 1
    Text = 'MANAGER'
  end
  object Edit3: TEdit
    Left = 344
    Top = 94
    Width = 121
    Height = 21
    TabOrder = 2
    Text = '192.168.15.32'
  end
  object Button1: TButton
    Left = 288
    Top = 160
    Width = 75
    Height = 25
    Caption = 'Button1'
    TabOrder = 3
    OnClick = Button1Click
  end
  object CheckBox1: TCheckBox
    Left = 344
    Top = 121
    Width = 97
    Height = 17
    Caption = 'direct'
    TabOrder = 4
  end
  object OraSession: TOraSession
    Left = 224
    Top = 184
  end
end
