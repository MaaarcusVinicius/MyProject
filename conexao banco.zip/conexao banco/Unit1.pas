unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, OraCall, Data.DB, DBAccess, Ora,
  Vcl.StdCtrls;

type
  TForm1 = class(TForm)
    OraSession: TOraSession;
    Label1: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Button1: TButton;
    CheckBox1: TCheckBox;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
begin
  OraSession.close;
  OraSession.Options.Direct := CheckBox1.Checked;
  OraSession.Password := Edit2.Text;
  OraSession.Username := Edit1.Text;
  OraSession.Server := Edit3.Text;
  OraSession.LoginPrompt := false;
  showmessage(OraSession.ConnectString);

  OraSession.Open;
  if OraSession.Connected then
    showmessage('CONECTOU...')
  else
    showmessage('n�o ..')
end;

end.
